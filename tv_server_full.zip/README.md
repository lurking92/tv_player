\# TV Subtitle Server（每 2.5 秒對齊）



\## 執行

```bash

npm install

npm start

\# 開 http://localhost:3000



