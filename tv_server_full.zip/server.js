// server.js
// 極簡靜態伺服器：只提供本機靜態檔，不含任何 /api
// Node.js 18+；請確保 package.json 有 "type": "module"

import express from "express";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

// 靜態根目錄：public/
// /manifest.json 會對應到 public/manifest.json
app.use(express.static(path.join(__dirname, "public")));

// 影片與字幕靜態路徑
app.use("/videos", express.static(path.join(__dirname, "videos")));
app.use("/subs", express.static(path.join(__dirname, "subs"))); // 目前未使用，預留

app.listen(PORT, () => {
  console.log(`static server at http://localhost:${PORT}`);
});
