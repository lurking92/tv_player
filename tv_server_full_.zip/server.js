// server.js
// 極簡靜態伺服器：只提供本機靜態檔，不含任何 /api
// Node.js 18+；請確保 package.json 有 "type": "module"

import "dotenv/config";
import express from "express";
import path from "path";
import cors from "cors";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(cors());
const PORT = process.env.PORT || 3000;

// 靜態根目錄：public/
// /manifest.json 會對應到 public/manifest.json
app.use(express.static(path.join(__dirname, "public")));

// 影片與字幕靜態路徑
app.use("/videos", express.static(path.join(__dirname, "videos")));
app.use("/subs", express.static(path.join(__dirname, "subs"))); // 目前未使用，預留

// ========== API: OpenRouter 影像分析 ==========
app.use(express.json({ limit: "15mb" }));

app.post("/api/analyze", async (req, res) => {
  try {
    const { dataUrl } = req.body || {};
    if (!dataUrl || typeof dataUrl !== "string") {
      return res.status(400).json({ error: "missing dataUrl" });
    }

    const model =
      process.env.OPENROUTER_MODEL ||
      "google/gemini-2.5-flash-image-preview:free";
    const apiKey = process.env.OPENROUTER_API_KEY || process.env.OPENROUTER_KEY;
    if (!apiKey) {
      return res
        .status(500)
        .json({ error: "server missing OPENROUTER_API_KEY" });
    }

    const payload = {
      model,
      messages: [
        {
          role: "user",
          content: [
            {
              type: "text",
              text: '你是安全監測助理，請檢視這張影像畫面，判斷是否出現以下行為：跌倒、爬高、奔跑、迷失方向。請回傳嚴格的 JSON（不要多餘文字），格式例如：{"fall":false,"climbing":false,"running":true,"disoriented":false}。只允許這四個鍵。',
            },
            { type: "image_url", image_url: { url: dataUrl } },
          ],
        },
      ],
      temperature: 0,
    };

    const resp = await fetch("https://openrouter.ai/api/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
        // 以下兩個標頭非必填，但可讓你的應用在 OpenRouter 儀表板上被辨識
        "HTTP-Referer": process.env.APP_URL || "http://localhost:3000",
        "X-Title": "TV Subtitle Server",
      },
      body: JSON.stringify(payload),
    });

    const data = await resp.json();
    let raw = data?.choices?.[0]?.message?.content;

    // OpenRouter 有些模型會把 content 當成 string 或 array
    if (Array.isArray(raw)) {
      raw = raw
        .map((p) => (typeof p === "string" ? p : p?.text || ""))
        .join("");
    }

    // 嘗試從回應抽取 JSON 物件
    let result = null;
    if (typeof raw === "string") {
      const m = raw.match(/\{[\s\S]*\}/);
      if (m) {
        try {
          result = JSON.parse(m[0]);
        } catch {}
      }
    }
    if (!result || typeof result !== "object") {
      result = {
        fall: false,
        climbing: false,
        running: false,
        disoriented: false,
      };
    }

    res.json({ result, raw });
  } catch (e) {
    console.error("analyze error", e);
    res.status(500).json({ error: String(e?.message || e) });
  }
});

app.listen(PORT, () => {
  console.log(`static server at http://localhost:${PORT}`);
});
